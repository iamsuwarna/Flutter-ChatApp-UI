import 'package:flutter_chat_ui/models/user_model.dart';

class Message {
  final User sender;
  final String
      time; // Would usually be type DateTime or Firebase Timestamp in production apps
  final String text;
  final bool isLiked;
  final bool unread;

  Message({
    this.sender,
    this.time,
    this.text,
    this.isLiked,
    this.unread,
  });
}

// YOU - current user
final User currentUser = User(
  id: 0,
  name: 'Current User',
  imageUrl: 'assets/images/14.jpg',
);

// USERS
final User William = User(
  id: 1,
  name: 'Wiliam Regal',
  imageUrl: 'assets/images/14.jpg',
);
final User Subarna = User(
  id: 2,
  name: 'Subarna Karki',
  imageUrl: 'assets/images/2.jpg',
);
final User Sassy = User(
  id: 3,
  name: 'Sassy Mahat',
  imageUrl: 'assets/images/3.jpg',
);
final User Alina = User(
  id: 4,
  name: 'Alina Basnet',
  imageUrl: 'assets/images/4.jpg',
);
final User Badri = User(
  id: 5,
  name: 'Badri Karki',
  imageUrl: 'assets/images/5.jpg',
);
final User Bhuwan = User(
  id: 6,
  name: 'Bhuwan Dahal',
  imageUrl: 'assets/images/6.jpg',
);
final User steven = User(
  id: 7,
  name: 'Steven Acharya',
  imageUrl: 'assets/images/14.jpg',
);

// FAVORITE CONTACTS
List<User> favorites = [Subarna, Sassy, Alina, Badri, Bhuwan];

// EXAMPLE CHATS ON HOME SCREEN
List<Message> chats = [
  Message(
    sender: Subarna,
    time: '10:30 PM',
    text: 'Hi, did you recognized me?',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Alina,
    time: '2:50 AM',
    text: 'Subarna, Did you complete the assignment?',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Sassy,
    time: '11:30 AM',
    text: 'It was nice meeting you ram!',
    isLiked: false,
    unread: false,
  ),
  Message(
    sender: Bhuwan,
    time: '7:30 PM',
    text: 'I am so tired today.......',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: steven,
    time: '7:30 PM',
    text: 'Will you come college tomorrow?',
    isLiked: false,
    unread: false,
  ),
  Message(
    sender: Badri,
    time: '1:00 AM',
    text: 'Where do you live?',
    isLiked: false,
    unread: false,
  ),
  Message(
    sender: William,
    time: '11:30 AM',
    text: 'I loved your presentation!',
    isLiked: false,
    unread: false,
  ),
];

// EXAMPLE MESSAGES IN CHAT SCREEN
List<Message> messages = [
  Message(
    sender: Subarna,
    time: '3:30 PM',
    text: 'Please donot try it again, Hahaha:-)',
    isLiked: true,
    unread: true,
  ),
  Message(
    sender: currentUser,
    time: '4:00 PM',
    text: 'Obviously!',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Subarna,
    time: '3:45 PM',
    text: 'You think that it was even good?',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Subarna,
    time: '3:15 PM',
    text: 'What a Horrible joke, My Lord!',
    isLiked: true,
    unread: true,
  ),
  Message(
    sender: currentUser,
    time: '2:30 PM',
    text: 'Ceiling, Sky, UFOs and many more:-) :-)',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Subarna,
    time: '2:00 PM',
    text: 'Hey, What\'s up?',
    isLiked: false,
    unread: true,
  ),
];
