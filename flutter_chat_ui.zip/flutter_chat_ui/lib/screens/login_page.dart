import 'package:flutter/material.dart';
import 'home_screen.dart';





class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool _secureText = true;

  TextEditingController _passwordController = TextEditingController();
  String _passwordError;

  var _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade300.withOpacity(0.7),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 30,),
              Text("Messenger",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 50,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 200),
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(
                  hintText: "Username",
                  labelText: "Username",
                  errorText: _passwordError,
                  labelStyle: TextStyle(fontSize: 24, color: Colors.black),
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(
                height: 26,
              ),
              Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        validator: (String value){
                          if(value.length < 10)
                            return "Enter at least 6 char";
                          else
                            return null;
                        },
                        decoration: InputDecoration(
                            suffixIcon: IconButton(
                              icon: Icon(
                                  _secureText ? Icons.remove_red_eye : Icons.security),
                              onPressed: () {
                                setState(() {
                                  _secureText = !_secureText;
                                });
                              },
                            ),
                            hintText: "Password",
                            labelText: "Password",
                            labelStyle: TextStyle(fontSize: 24, color: Colors.black),
                            border: OutlineInputBorder()),
                        obscureText: _secureText,
                      ),
                      SizedBox(
                        height: 26,
                      ),
                    ],
                  )),




              Text("Don't have an account? Sign Up",
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 25),


              GestureDetector(
                child: Container(
                  height: 70,
                  width: 200,
                  decoration:BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15)
                  ),
                  child: Center(
                    child: Text(
                      'Start Quiz',
                      style: TextStyle(
                          fontSize: 25,
                          fontFamily: 'Avenir',
                          color: Colors.black,
                          fontWeight: FontWeight.bold
                      ),
                    ),
                  ),
                ),

                onTap: (){

                  print("Password : " + _passwordController.text);
                  setState(() {
                    print("Form Validation : " + _formKey.currentState.validate().toString());
                    if(_passwordController.text.length < 3){
                      _passwordError = "Enter at least 10 characters";
                    }

                    else{

                      Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeScreen()));
                    }
                  });
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}




